<template>
	<div>
		<div class="container px-1 px-md-4 py-5 mx-auto">
			<div class="card">
				<div class="row d-flex justify-content-between px-3 top">
					<div class="d-flex">
						<h5>ETA : 20MIN</h5>
					</div>
					<div class="d-flex flex-column text-sm-right">
						<p class="mb-0">01/12/19</p>
						<p class="mb-0">Order ID: <span class="font-weight-bold">WR345GT090</span></p>
					</div>
				</div>
				<div class="row justify-content-between top">
					<div class="col-md-8 left">
						<div id="border">
						<div id="circle"></div>
						<div class="row d-flex icon-content">
							<img class="icon" src="https://www.iconfinder.com/data/icons/shopping-e-commerce-3-1/32/Order-Received-List-Detail-512.png">
							<div class="d-flex flex-column">
								<p class="font-weight-bold">Order Recieved</p>
								<span class="font-weight-bold">Your order has been received </span>
							</div>
						</div>

					</div>
					<div id="vb"></div>
					<div id="border">
						<div id="circle"></div>
						<div class="row d-flex icon-content">
							<img class="icon" src="https://www.iconfinder.com/data/icons/canoopi-seafood-product-packaging/64/Quick_and_easy_to_prepare-512.png">
							<div class="d-flex flex-column">
								<p class="font-weight-bold">Preparing </p>
								<span class="font-weight-bold">We are preparing your food </span>
							</div>
						</div>
					</div>
					<div id="vbb"></div>
					<div id="border">
						<div id="circle-div"></div>
						<div class="row d-flex icon-content" id="hover">
							<img class="icon" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRhwt0RYF6pBbP7yCajRh7iRu9LmcIYTSziNw&usqp=CAU">
							<div class="d-flex flex-column">
								<p class="font-weight-bold">Ready to Serve</p>
								<span class="font-weight-bold">We ready to serve your food</span>
							</div>
						</div>
					</div>
				</div>
				<div class="">
					<div class="col-md-4 right">
						<label>Amount Details</label>
						

					</div>
					<div class="col-md-4 right">
						<label id="left">Item 1:</label>
						<p id="right">30.00rs</p>

					</div>
					<div class="col-md-4 right">
						<label id="left">Item 2:</label>
						<p id="right">130.00rs</p>

					</div>
					
					<div class="col-md-4 right">
						<label id="left">GST:</label>
						<p id="right">130.00rs</p>
						<br>
						<hr>

					</div>

					<div class="col-md-4 right">
						<label id="left">Total Amount:</label>
						<p id="right">567.00rs</p>


					</div>
					<div class="col-md-4 right">
						<label id="left">Discount Amount:</label>
						<p id="right">70.00rs</p>
						<br>
						<hr>


					</div>
					<div class="col-md-4 right">
						<label id="left">Payable Amount:</label>
						<p id="right">497.00rs</p>


					</div>
				</div>
					
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	

</script>

<style>
.left,#left{
	float: left;
}
.right,#right{
	float: right;
}
p.mb-0{

margin-right: 30px;
}
h5{
margin-left: 47px;
}
.icon-content {
    width: 80% !important;
}
span.font-weight-bold{

    font-weight: 400 !important;
    font-size: 12px;
}
p{
margin-bottom: 0px !important;
}
.row{
display: block !important;
}
#border{
display:flex;
}
#vbb{
	margin-left: 2px !important;

	border-left: 6px solid #a9c7a9;height: 70px;
  border-style: dotted;
  border-right:none;
  border-top:none;
  border-bottom: none;

}
#vb{
margin-left: 2px !important;

border-left: 6px solid green;
  height: 70px;
  border-style: dotted;
  border-right:none;
  border-top:none;
  border-bottom: none;
}
.icon{
width: 30px !important;
height: 30px !important;
}
.icon-content{

padding-bottom: 0px !important;
}
body {
    color: #000;
    overflow-x: hidden;
    height: 100%;
    background-color: #8C9EFF;
    background-repeat: no-repeat
}
.vertical_dotted_line
{
    border-left: 1px dotted black;
    height: 100px;
    margin-left: 10px;
} 
.card {
    z-index: 0;
    background-color: #ECEFF1;
    padding-bottom: 20px;
    margin-top: 90px;
    margin-bottom: 90px;
    border-radius: 10px
}

.top {
    padding-top: 40px;
    padding-left: 13% !important;
    padding-right: 13% !important
}

div#circle {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-top: 15px;
  background: blue;
  margin-right: 45px;
}
div#circle-div {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-top: 15px;
  background: #9898d4;
  margin-right: 45px;
}

#progressbar {
    margin-bottom: 30px;
    overflow: hidden;
    color: #455A64;
    padding-left: 0px;
    margin-top: 30px
}

#progressbar li {
    list-style-type: none;
    font-size: 13px;
    width: 25%;
    float: left;
    position: relative;
    font-weight: 400
}

#progressbar .step0:before {
    font-family: FontAwesome;
    content: "\f10c";
    color: #fff
}

#progressbar li:before {
    width: 40px;
    height: 40px;
    line-height: 45px;
    display: block;
    font-size: 20px;
    background: #C5CAE9;
    border-radius: 50%;
    margin: auto;
    padding: 0px
}

#progressbar li:after {
    content: '';
    width: 100%;
    height: 12px;
    background: #C5CAE9;
    position: absolute;
    left: 0;
    top: 16px;
    z-index: -1
}

#progressbar li:last-child:after {
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    position: absolute;
    left: -50%
}

#progressbar li:nth-child(2):after,
#progressbar li:nth-child(3):after {
    left: -50%
}

#progressbar li:first-child:after {
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    position: absolute;
    left: 50%
}

#progressbar li:last-child:after {
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px
}

#progressbar li:first-child:after {
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px
}

#progressbar li.active:before,
#progressbar li.active:after {
    background: #651FFF
}

#progressbar li.active:before {
    font-family: FontAwesome;
    content: "\f00c"
}

.icon {
    width: 60px;
    height: 60px;
    margin-right: 15px
}

.icon-content {
    padding-bottom: 20px
}

@media screen and (max-width: 992px) {
    .icon-content {
        width: 50%
    }
}

body, html, .main {
  height: 100%;
}

section {
  min-height: 100%;
}
</style>