<template>
  <div class="OrderList">
    <ListView msg="Welcome to Your Vue.js + TypeScript App"></ListView>
  </div>
</template>
<script lang="ts">
import { Options, Vue } from 'vue-class-component';
// import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src
import ListView from '@/components/ListView.vue'; // @ is an alias to /src
// import "@/assets/assets/extra-libs/DataTables/datatables.min.js";
	// import "@/assets/bootstrap.min.js";
	// import "@/assets/font-awesome.min.css";
	// import "@/assets/jquery.min.js";
@Options({
  components: {
    // HelloWorld,
    ListView,
  },
})
export default class OrderList extends Vue {

}
</script>