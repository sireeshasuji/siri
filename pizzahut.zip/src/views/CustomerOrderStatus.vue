<template>
  <div class="OrderStatus">
    <!-- <img alt="Vue logo" src="../assets/logo.png"> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js + TypeScript App"/> -->
    <OrderStatus msg="Welcome to Your Vue.js + TypeScript App"></OrderStatus>
  </div>
</template>

<script lang="ts">
import { Options, Vue } from 'vue-class-component';
// import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src
import OrderStatus from '@/components/OrderStatus.vue'; // @ is an alias to /src
import "@/assets/bootstrap.min.css";
import "@/assets/assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.css";
// import "@/assets/assets/extra-libs/DataTables/datatables.min.js";
	// import "@/assets/bootstrap.min.js";
	// import "@/assets/font-awesome.min.css";
	// import "@/assets/jquery.min.js";
@Options({
  components: {
    // HelloWorld,
    OrderStatus,
  },
})
export default class CustomerOrderStatus extends Vue {

}
</script>
